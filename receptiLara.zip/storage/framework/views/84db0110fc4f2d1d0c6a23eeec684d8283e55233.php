<?php $__env->startSection('content'); ?>

<?php
  $kategorije = App\kategorije2::all();
?>

<div class="jumbotron">


<br> <br>

<div>

<?php $__currentLoopData = $kategorije; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategorija): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<a href="/receptiKategorije/<?php echo e($kategorija->id); ?>">

    <button class="btn btn-primary btn-block">
        <p> <?php echo e($kategorija->naziv_kategorije); ?> </p>
    </button>

</a>

<br>
<br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>