<?php $__env->startSection('content'); ?>





<table class="table">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Ime</th>
        <th scope="col">Email</th>
      </tr>
    </thead>
    <?php $__currentLoopData = $kuhari; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kuhar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tbody>
      <tr>
      <th scope="row"><?php echo e($kuhar->id); ?></th>
      <td><?php echo e($kuhar->name); ?></td>
      <td><?php echo e($kuhar->email); ?></td>
      <td></td>
      </tr>
    </tbody>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>

  <br>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>