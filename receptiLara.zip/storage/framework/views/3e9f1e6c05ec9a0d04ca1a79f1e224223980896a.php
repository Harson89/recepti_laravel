<?php $__env->startSection('content'); ?>

<table class="table">
    <thead>
      <tr>
        <th scope="col">Otvori</th>
        <th scope="col">Naziv recepta</th>
        <th scope="col">Kuhar</th>
        <th scope="col">Slika</th>

      </tr>
    </thead>
    <tbody>
         <?php $__currentLoopData = $recepti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recepat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
          <?php
            $imeKuhara= App\User::where('id', $recepat->user_id)->get();
            foreach($imeKuhara as $kuhar){
                $ime = $kuhar->name;
            }
          ?>
      <th scope="row">
        <a href="pojedinacanRecept/<?php echo e($zaPrikaz = $recepat->id); ?>"> <button class="btn btn-outline-secondary"> Otvori </button> </a>  </td>
      </th>
        <td><?php echo e($recepat->naziv_recepta); ?></td>
        <td><?php echo e($ime); ?></td>
      <td> <img src="<?php echo e($recepat->slika); ?>" class="img-fluid" alt="Responsive image" width="500px" height="500px" > </td>
      </tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>