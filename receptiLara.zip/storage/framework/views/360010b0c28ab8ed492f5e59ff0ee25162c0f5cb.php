<?php $__env->startSection('content'); ?>



<?php $__currentLoopData = $ovajRecept; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prikaz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

{



<div class="card">
<h3 class="card-header text-center font-weight-bold text-uppercase py-4"><?php echo e($prikaz->naziv_recepta); ?></h3>
    <div class="card-body">
      <div id="table" class="table-editable">
        <span class="table-add float-right mb-3 mr-2"><a href="#!" class="text-success"><i class="fa fa-plus fa-2x"
              aria-hidden="true"></i></a></span>
        <table class="table table-bordered table-responsive-md table-striped text-center">
          <tr>
            <th class="text-center">Naziv Recepta</th>
            <th class="text-center">Kuhar</th>
            <th class="text-center">Priprema</th>
            <th class="text-center">Slika</th>
          </tr>
          <tr>
          <td class="pt-3-half" contenteditable="true"><?php echo e($prikaz->naziv_recepta); ?></td>

          <?php
          $imeKuhara= App\User::where('id', $prikaz->user_id)->get();
          foreach($imeKuhara as $kuhar){
              $ime = $kuhar->name;
          }
          ?>

            <td class="pt-3-half" contenteditable="true"><?php echo e($ime); ?></td>
        <td class="pt-3-half" contenteditable="true" style="width: 35%; word-break:break-all;""><?php echo nl2br($prikaz->priprema) ?></td>
            <td class="pt-3-half">
                <img src="<?php echo e($prikaz->slika); ?>" class="img-fluid" alt="Responsive image">
            </td>
          </tr>
        </table>
      </div>
    </div>
  </div>


 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>