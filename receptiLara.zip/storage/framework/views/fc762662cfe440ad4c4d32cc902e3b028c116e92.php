<?php $__env->startSection('content'); ?>



<table class="table">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Naziv recepta</th>
        <th scope="col">Priprema</th>
        <th scope="col">Slika</th>

      </tr>
    </thead>
    <tbody>
         <?php $__currentLoopData = $recepti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recepat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <tr>
      <th scope="row"><?php echo e($recepat->id); ?></th>

        <td><?php echo e($recepat->naziv_recepta); ?></td>
        <td style="width: 35%; word-break:break-all;"><?php echo e($recepat->priprema); ?></td>
      <td> <img src="<?php echo e($recepat->slika); ?>" class="img-thumbnail" alt="Cinque Terre" width="500px" height="500px"> </td>
      <td> <a href="/urediRecepat/<?php echo e($za_urediti = $recepat->id); ?>"> <button class="btn btn-outline-secondary"> Uredi </button> </a>  </td>
      <!-- <td> <a href="/edit/<?php echo e($za_izbrisati=$recepat->id); ?>"> <button class="btn btn-outline-secondary"> Uredi </button> </a>  </td>-->
      <td> <a href="/mojiRecepti/<?php echo e($za_izbrisati = $recepat->id); ?>"> <button class="btn btn-outline-secondary"> Izbriši </button> </a> </td>
      <td>  </td>
      </tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>