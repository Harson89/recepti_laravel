<?php $__env->startSection('content'); ?>

<?php
$trenutnaKategorija = $receptiKategorije;
?>

<table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Naziv recepta</th>
            <th scope="col">Kuhar</th>
            <th scope="col">Priprema</th>
            <th scope="col">Slika</th>

          </tr>
        </thead>
        <tbody>
             <?php $__currentLoopData = $trenutnaKategorija; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receptiTe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <tr>
                <?php
                $imeKuhara= App\User::where('id', $receptiTe->user_id)->get();
                foreach($imeKuhara as $kuhar){
                    $ime = $kuhar->name;
                }
             ?>
          <th scope="row"><?php echo e($receptiTe->id); ?></th>
            <td><?php echo e($receptiTe->naziv_recepta); ?></td>
            <td><?php echo e($ime); ?></td>
            <td style="width: 35%; word-break:break-all;"><?php echo e($receptiTe->priprema); ?></td>
          <td> <img src="<?php echo e($receptiTe->slika); ?>" class="img-fluid" alt="Responsive image" width="500px" height="500px"> </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>