<?php $__env->startSection('content'); ?>

<form>

        <div class="form-group row">
          <label for="nazivRecepta" class="col-sm-2 col-form-label">Naziv Recepta:</label>
          <div class="col-sm-10">
            <input type="password" class="form-control" id="nazivRecepta" placeholder="Ovdje unesite naziv svog recepta">
          </div>
        </div>

        <div class="form-group row">
                <label for="priprema" class="col-sm-2 col-form-label">Priprema:</label>
                <div class="col-sm-10">
                        <textarea class="form-control" rows="5" id="priprema" placeholder="Ovdje upišite način pripreme recepta"></textarea>
                </div>
              </div>

              <div class="form-group col-md-4">
                    <lable>Kategorija</lable>
                    <select name="kategorija">
                      <option value="Mumbai">Mumbai</option>
                      <option value="Chennai">Chennai</option>
                      <option value="Delhi">Delhi</option>
                      <option value="Bangalore">Bangalore</option>
                    </select>
                </div>


      </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>