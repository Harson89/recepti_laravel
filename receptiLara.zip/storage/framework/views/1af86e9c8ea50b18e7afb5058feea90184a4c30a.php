<?php $__env->startSection('content'); ?>


<h1 class="text-center"> O NAMA  <h1>

    <br> <br>

<div class="well">

Svi recepti na jednom mijestu.Ovo je najveca baza recepatana cijelome svijetu.Registruj se i pridruži se skupini
najboljih kuhara na svijetu. Reklamiraj sebe potpuno besplatnoi podjeli svoje kuhinjsko umijeće sa cijelim svijetom.
Naš web site postji vec dugi niz godina i uspiješno poslujemo sa najpoznatijim vodećim brendovima u svijetu.Naš web site
jos nije u potpunoj verziji.Ako nas želite podržati podijelite naš sadržaj na društvernim mrežama


</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>