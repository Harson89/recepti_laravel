# recepti_laravel


Recepti za hranu pravljen u Laravelu

RECEPTI 

Za sta sluzi moj web site:

Moj web site sluzi za dodavanje,pregledanje,editovanje recepata.

Kako funkcionise web site:

Moj web site funkcioniše na slejdeci nacin.Kada tek pristupite sajtu imate mogucnost da se registrujete ili loginujete.Sve dok to ne uradite imate samo mogućnost pregledanja sadržaja na web sajtu.Možete pregledati kategorije,recepte,recepte po kategorijama,prijavljene usere odnosno "Kuhare",stranu "O Nama" i mozete se registrovati ili prijaviti.
Kada se registrujete ako nemate napravljen korisnicki racun ili loginujete ako vec imate napravljen korisnici racun,onda imate dodatnu opciju u nav baru a to je "Moj profil".

Kada idete na drop menu "Moj profil" dobit cete dvije opcije a to su:

-Dodaj novi recepat
-Moji recepti

Kada idete na opciju "Dodaj novi recepat" otvori vam se forma za dodavanje novog recepta.U toj formi ste dužni unijeti naziv recepta,opis pripreme,odabrati kategoriju recepta i dodati sliku.Nakon submita se ti podaci sa forme koriste za dodavanje novog recepta u bazu i vi cete biti preusmjereni ponovo na stranu "Moji recepti" sa novim recepom.

Druga opcija je "Moji recepti".Kada ozaberete tu opciju otvori vam se novi page "Moji recepti".Gdje su ispisani svi recepti koji su u vasem vlasnistvu.Pored svakog recepta se ispisu dva dugmeta.Jedno dugme je "izbrisi" a drugo je "Uredi".Nakog odabira "izbrisi" dugmeta,izabrani recept ce se izbrisati iz baze a vi cete ponovo biti preusmjereni na "Moji recepti" page.Kada odaberete opciju "Uredi",otvorit ce vam se forma za uređivanje odabranog recepta.U svakom polju su ispisani vec postojeci podaci koji nakon novog unosa se mjenjaju u bazi.

![slika baze](https://user-images.githubusercontent.com/37156656/46005557-c9ad6e00-c0b5-11e8-9bf9-97c2b839576e.png)


